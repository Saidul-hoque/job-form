# jobforme-in-django

it like online service for post jobs and apply those job 
### pip install django
### python manage.py makemigration 
### python manage.py migrate
### python manage.py runserver
